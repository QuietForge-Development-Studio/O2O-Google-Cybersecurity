# Cybersecurity Course Organizer

Modular Python app to scaffold and consolidate Google Cybersecurity Certificate course notes.
