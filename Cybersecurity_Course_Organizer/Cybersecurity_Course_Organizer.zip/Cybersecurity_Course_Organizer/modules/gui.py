# GUI logic (Tkinter or Flask)

def run_gui():
    print("GUI not implemented yet.")
