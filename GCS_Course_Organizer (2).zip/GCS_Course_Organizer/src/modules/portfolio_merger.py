# Logic for consolidating portfolio files

def consolidate_portfolio():
    pass
# This function will handle the logic for merging multiple portfolio files into a single consolidated file.
# It will pull data from /portfolio folders in modules that feature portfolio activities, then copy them, preserving the original files.
# this script will be run at the end of the course to create a final portfolio file that includes all activities from all modules.
#the script will create a new folder called "Final_Portfolio" in the root directory of the course, and popuulate it with the contents of all "portfolio" folders in all subdirectories.