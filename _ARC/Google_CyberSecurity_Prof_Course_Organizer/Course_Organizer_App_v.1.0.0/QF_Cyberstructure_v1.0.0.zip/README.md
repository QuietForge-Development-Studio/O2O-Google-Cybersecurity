# 🛡️ Quiet Forge | Cybersecurity Course Folder Generator

A fully-automated Python utility for creating structured, named folders for the [Google Cybersecurity Professional Certificate](https://grow.google/certificates/cybersecurity/). 

---

## 🚀 Features

- 🧱 **Prebuilt structure**: Mirrors the official 8-module course layout
- 🔢 **Simple naming**: Uses `1.1.2` (Course.Module.Topic) indexing
- 📂 **Auto-generated**: Folders include `Labs`, `Readings`, `Assignments`, and `Scripts`
- 📝 **Built-in README**: Each topic folder contains a placeholder `README` for your notes

---

## 🎛️ Usage

Place both files in your working directory:
- `deploy_course_structure.py`
- `google_cybersecurity_course_structure.json`

Then run:

```bash
python deploy_course_structure.py
```

You’ll be prompted to:
```
📚 Quiet Forge | Google Cybersecurity Structure Builder
-------------------------------------------------------
1. Full Certificate Deployment
2. Single Module Deployment (1–9)
Choose an option [1/2]:
```

---

## 🗂️ Output Example

```
Course_1_Foundations_of_Cybersecurity/
└── Module_1/
    └── 1.1_Introduction_to_cybersecurity/
        ├── coach_1.1.1.txt
        ├── README_1.1.1.md
        ├── Labs/
        ├── Readings/
        ├── Assignments/
        └── Scripts/
```

---

## ✅ License

MIT License – free to use, adapt, or extend. Contributions welcome.

---

## 🧠 Created by Quiet Forge

> A collective of developers, builders, and digital explorers  
> [quietforge.dev](https://quietforge.dev) | crafted with ⚔️ & 🔥
